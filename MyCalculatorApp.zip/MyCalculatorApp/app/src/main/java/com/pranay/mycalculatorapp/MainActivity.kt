package com.pranay.mycalculatorapp

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    private lateinit var num1EditText: EditText
    private lateinit var num2EditText: EditText
    private lateinit var resultTextView: TextView

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_main)

            //Initialize references to the UI components
        resultTextView = findViewById<TextView>(R.id.editTextNumber)
            num1EditText = findViewById<EditText>(R.id.num1editTextNumber)
        num2EditText = findViewById<EditText>(R.id.num2edittextNumber)

            //Initialize all the UI components
        val additionButton = findViewById<Button>(R.id.buttonPlus)
            additionButton.setOnClickListener { performCalculation("+") }

        val subtractionButton = findViewById<Button>(R.id.buttonMinus)
        subtractionButton.setOnClickListener { performCalculation("-") }

        val multiplicationButton = findViewById<Button>(R.id.buttonMultiply)
        multiplicationButton.setOnClickListener { performCalculation("*") }

        val divisionButton = findViewById<Button>(R.id.buttonDivide)
        divisionButton.setOnClickListener { performCalculation("/") }

        val clearButton = findViewById<Button>(R.id.buttonClear)
            clearButton.setOnClickListener {
                num1EditText.setText("")
                num2EditText.setText("")
                resultTextView.text = ""

            }
    }

    @SuppressLint("SetTextI18n")
    private fun performCalculation(operation:String){

        val num1 = num1EditText.text.toString().toIntOrNull() ?: return
        val num2 = num2EditText.text.toString().toIntOrNull() ?: return

        val result = when (operation) {
            "+" -> num1 + num2
            "-" -> num1 - num2
            "*" -> num1 * num2
            "/" -> if (num1 !=0) num1 / num2 else Double.NaN
            else -> Double.NaN
        }

        resultTextView.text = "Result: $num1 $operation $num2 = $result"
        //https://www.youtube.com/watch?v=xwOCmJevigw
    }

}